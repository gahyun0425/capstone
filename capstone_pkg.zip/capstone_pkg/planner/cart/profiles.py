from __future__ import annotations

from dataclasses import asdict, dataclass, field
import json
import math
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple


@dataclass
class CartGoalProfile:
    angular_z: float
    q_goal: List[float]
    left_target_xyz: List[float]
    left_target_quat_wxyz: List[float]
    right_target_xyz: List[float]
    right_target_quat_wxyz: List[float]
    q_path: List[List[float]] = field(default_factory=list)
    label: str = ""
    score: float = 0.0
    left_force_capacity: float = 0.0
    right_force_capacity: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class CartStoredTransition:
    start_angular_z: float
    goal_angular_z: float
    start_range_label: str
    goal_range_label: str
    q_path: List[List[float]] = field(default_factory=list)
    label: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class CartGoalLibrary:
    version: int
    max_abs_angular_z: float
    q_reference_cspace: List[float]
    cspace_joint_names: List[str]
    profiles: List[CartGoalProfile]
    stored_transitions: List[CartStoredTransition] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


def clamp_angular_z(angular_z: float, max_abs_angular_z: float) -> float:
    max_abs = float(max_abs_angular_z)
    if max_abs <= 0.0:
        raise ValueError("max_abs_angular_z must be > 0")
    z = float(angular_z)
    return max(-max_abs, min(max_abs, z))


def angular_z_to_ratio(angular_z: float, max_abs_angular_z: float) -> float:
    return clamp_angular_z(angular_z, max_abs_angular_z) / float(max_abs_angular_z)


def save_cart_goal_library(path: str | Path, library: CartGoalLibrary) -> None:
    out_path = Path(path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", encoding="utf-8") as f:
        json.dump(asdict(library), f, indent=2, ensure_ascii=True)


def load_cart_goal_library(path: str | Path) -> CartGoalLibrary:
    in_path = Path(path)
    with in_path.open("r", encoding="utf-8") as f:
        raw = json.load(f)

    profiles = [
        CartGoalProfile(
            angular_z=float(item["angular_z"]),
            q_goal=[float(v) for v in item["q_goal"]],
            q_path=[
                [float(v) for v in row]
                for row in item.get("q_path", [])
            ],
            left_target_xyz=[float(v) for v in item["left_target_xyz"]],
            left_target_quat_wxyz=[float(v) for v in item["left_target_quat_wxyz"]],
            right_target_xyz=[float(v) for v in item["right_target_xyz"]],
            right_target_quat_wxyz=[float(v) for v in item["right_target_quat_wxyz"]],
            label=str(item.get("label", "")),
            score=float(item.get("score", 0.0)),
            left_force_capacity=float(item.get("left_force_capacity", 0.0)),
            right_force_capacity=float(item.get("right_force_capacity", 0.0)),
            metadata=dict(item.get("metadata", {})),
        )
        for item in raw.get("profiles", [])
    ]

    stored_transitions = [
        CartStoredTransition(
            start_angular_z=float(item["start_angular_z"]),
            goal_angular_z=float(item["goal_angular_z"]),
            start_range_label=str(item.get("start_range_label", "")),
            goal_range_label=str(item.get("goal_range_label", "")),
            q_path=[
                [float(v) for v in row]
                for row in item.get("q_path", [])
            ],
            label=str(item.get("label", "")),
            metadata=dict(item.get("metadata", {})),
        )
        for item in raw.get("stored_transitions", [])
    ]

    library = CartGoalLibrary(
        version=int(raw.get("version", 1)),
        max_abs_angular_z=float(raw["max_abs_angular_z"]),
        q_reference_cspace=[float(v) for v in raw["q_reference_cspace"]],
        cspace_joint_names=[str(v) for v in raw["cspace_joint_names"]],
        profiles=profiles,
        stored_transitions=stored_transitions,
        metadata=dict(raw.get("metadata", {})),
    )
    validate_cart_goal_library(library)
    return library


def validate_cart_goal_library(library: CartGoalLibrary) -> None:
    dof = len(library.cspace_joint_names)
    if dof == 0:
        raise ValueError("cspace_joint_names is empty")
    if len(library.q_reference_cspace) != dof:
        raise ValueError(
            "q_reference_cspace length mismatch: "
            f"expected {dof}, got {len(library.q_reference_cspace)}"
        )
    if not library.profiles:
        raise ValueError("profiles is empty")

    for idx, profile in enumerate(library.profiles):
        if len(profile.q_goal) != dof:
            raise ValueError(
                f"profile[{idx}] q_goal length mismatch: expected {dof}, got {len(profile.q_goal)}"
            )
        for path_idx, row in enumerate(profile.q_path):
            if len(row) != dof:
                raise ValueError(
                    f"profile[{idx}] q_path[{path_idx}] length mismatch: expected {dof}, got {len(row)}"
                )
        if len(profile.left_target_xyz) != 3 or len(profile.right_target_xyz) != 3:
            raise ValueError(f"profile[{idx}] target xyz must have length 3")
        if len(profile.left_target_quat_wxyz) != 4 or len(profile.right_target_quat_wxyz) != 4:
            raise ValueError(f"profile[{idx}] target quat must have length 4")

    for idx, transition in enumerate(library.stored_transitions):
        if not transition.q_path:
            raise ValueError(f"stored_transitions[{idx}] q_path is empty")
        if not transition.start_range_label or not transition.goal_range_label:
            raise ValueError(f"stored_transitions[{idx}] range labels must be non-empty")
        for path_idx, row in enumerate(transition.q_path):
            if len(row) != dof:
                raise ValueError(
                    "stored_transitions[{}] q_path[{}] length mismatch: expected {}, got {}".format(
                        idx,
                        path_idx,
                        dof,
                        len(row),
                    )
                )


def get_profile_angular_range(profile: CartGoalProfile) -> Tuple[float, float] | None:
    raw_min = profile.metadata.get("selected_range_min_angular_z")
    raw_max = profile.metadata.get("selected_range_max_angular_z")
    if raw_min is None or raw_max is None:
        return None

    range_min = float(raw_min)
    range_max = float(raw_max)
    if range_min > range_max:
        range_min, range_max = range_max, range_min
    return range_min, range_max


def get_profile_range_label(profile: CartGoalProfile) -> str:
    raw = str(profile.metadata.get("selected_range_label", "")).strip()
    if raw:
        return raw
    if profile.label:
        return str(profile.label)
    return "angular_z_{:+.2f}".format(float(profile.angular_z))


def get_profile_anchor_angular_z(profile: CartGoalProfile) -> float:
    raw = profile.metadata.get("selected_anchor_angular_z")
    if raw is None:
        return float(profile.angular_z)
    return float(raw)


def get_range_representative_profiles(library: CartGoalLibrary) -> Dict[str, CartGoalProfile]:
    grouped: Dict[str, List[CartGoalProfile]] = {}
    for profile in library.profiles:
        grouped.setdefault(get_profile_range_label(profile), []).append(profile)

    representatives: Dict[str, CartGoalProfile] = {}
    for range_label, profiles in grouped.items():
        representatives[range_label] = min(
            profiles,
            key=lambda item: (
                abs(float(item.angular_z) - get_profile_anchor_angular_z(item)),
                abs(float(item.angular_z)),
                float(item.score),
            ),
        )
    return representatives


def infer_start_profile_from_q(
    library: CartGoalLibrary,
    q_current: Sequence[float],
) -> Tuple[CartGoalProfile, float, float]:
    if not q_current:
        raise ValueError("q_current is empty")

    representatives = get_range_representative_profiles(library)
    if not representatives:
        raise ValueError("no representative profiles available")

    candidates = []
    for profile in representatives.values():
        dof = min(len(profile.q_goal), len(q_current))
        diffs = [abs(float(profile.q_goal[i]) - float(q_current[i])) for i in range(dof)]
        max_abs_err = max(diffs) if diffs else math.inf
        l2_err = math.sqrt(sum(diff * diff for diff in diffs)) if diffs else math.inf
        candidates.append(
            (
                float(max_abs_err),
                float(l2_err),
                abs(float(profile.angular_z)),
                profile,
            )
        )

    best_max_abs_err, best_l2_err, _, best_profile = min(candidates, key=lambda item: (item[0], item[1], item[2]))
    return best_profile, float(best_max_abs_err), float(best_l2_err)


def find_stored_transition(
    library: CartGoalLibrary,
    *,
    start_range_label: str,
    goal_range_label: str,
) -> CartStoredTransition | None:
    ordered = [
        item
        for item in library.stored_transitions
        if str(item.start_range_label) == str(start_range_label)
        and str(item.goal_range_label) == str(goal_range_label)
    ]
    if not ordered:
        return None
    return sorted(
        ordered,
        key=lambda item: (
            abs(float(item.start_angular_z)),
            abs(float(item.goal_angular_z)),
            str(item.label),
        ),
    )[0]


def upsert_stored_transition(
    library: CartGoalLibrary,
    transition: CartStoredTransition,
) -> str:
    for idx, item in enumerate(library.stored_transitions):
        if (
            str(item.start_range_label) == str(transition.start_range_label)
            and str(item.goal_range_label) == str(transition.goal_range_label)
        ):
            library.stored_transitions[idx] = transition
            return "updated"

    library.stored_transitions.append(transition)
    return "added"


def select_cart_goal_profiles(
    library: CartGoalLibrary,
    angular_z: float,
    *,
    count: int = 1,
) -> Tuple[List[CartGoalProfile], float]:
    validate_cart_goal_library(library)
    if count <= 0:
        raise ValueError("count must be >= 1")

    clamped = clamp_angular_z(angular_z, library.max_abs_angular_z)
    range_matched: List[CartGoalProfile] = []
    fallback_pool: List[tuple[float, float, CartGoalProfile]] = []
    for profile in library.profiles:
        angular_range = get_profile_angular_range(profile)
        if angular_range is None:
            fallback_pool.append(
                (
                    abs(float(profile.angular_z) - clamped),
                    abs(float(profile.angular_z)),
                    profile,
                )
            )
            continue

        range_min, range_max = angular_range
        if (range_min - 1.0e-9) <= clamped <= (range_max + 1.0e-9):
            range_matched.append(profile)
            continue

        range_distance = min(abs(clamped - range_min), abs(clamped - range_max))
        fallback_pool.append(
            (
                float(range_distance),
                abs(float(profile.angular_z) - clamped),
                profile,
            )
        )

    if range_matched:
        ordered = sorted(
            range_matched,
            key=lambda item: (
                abs(float(item.angular_z) - clamped),
                abs(float(item.angular_z)),
            ),
        )
        return ordered[: min(int(count), len(ordered))], clamped

    ordered = [
        profile
        for _, _, profile in sorted(
            fallback_pool,
            key=lambda item: (item[0], item[1], abs(float(item[2].angular_z))),
        )
    ]
    return ordered[: min(int(count), len(ordered))], clamped


def describe_selected_profiles(
    profiles: Sequence[CartGoalProfile],
    *,
    requested_angular_z: float,
    clamped_angular_z: float,
) -> List[str]:
    lines = [
        "requested angular.z = {:.6f}".format(float(requested_angular_z)),
        "clamped angular.z   = {:.6f}".format(float(clamped_angular_z)),
    ]
    for idx, profile in enumerate(profiles):
        label = profile.label if profile.label else f"profile_{idx}"
        angular_range = get_profile_angular_range(profile)
        range_text = ""
        if angular_range is not None:
            range_text = " range=[{:.6f}, {:.6f}]".format(
                float(angular_range[0]),
                float(angular_range[1]),
            )
        lines.append(
            "[{}] angular.z={:.6f} score={:.6f} label={}{} range_label={}".format(
                idx,
                float(profile.angular_z),
                float(profile.score),
                label,
                range_text,
                get_profile_range_label(profile),
            )
        )
    return lines
