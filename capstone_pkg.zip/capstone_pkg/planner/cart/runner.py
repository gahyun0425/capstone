from __future__ import annotations

import argparse
import math
import time
from typing import List, Sequence

import torch

from capstone_pkg.collision_check.collision import get_self_collision_checker
from capstone_pkg.collision_check.edge_collision import EdgeCollisionChecker
from capstone_pkg.constraint_projection.constraint import RigidConstraint
from capstone_pkg.constraint_projection.projection import ManifoldProjector
from capstone_pkg.planner.bidir_rrt.path_publisher import (
    JointTrajectoryCommand,
    publish_joint_trajectory_group,
    send_joint_trajectory_action_group,
)
from capstone_pkg.planner.cart.profiles import (
    CartGoalProfile,
    CartStoredTransition,
    describe_selected_profiles,
    find_stored_transition,
    get_profile_anchor_angular_z,
    get_profile_range_label,
    infer_start_profile_from_q,
    load_cart_goal_library,
    save_cart_goal_library,
    select_cart_goal_profiles,
    upsert_stored_transition,
)
from capstone_pkg.planner.start_goal import get_q_start_from_jointstate
from capstone_pkg.planner.tbrrt import TBRRTConfig
from capstone_pkg.planner.tbrrt.basic_tbrrt.basic_tbrrt import plan_tbrrt_extcon
from capstone_pkg.planner.tbrrt.postprocess import lazy_project_path, path_to_list
from capstone_pkg.utils.config import (
    JOINT_LIMIT,
    LEFT_EE_FRAME,
    LEFT_JOINTS,
    RIGHT_EE_FRAME,
    RIGHT_JOINTS,
    ROBOT_XML,
    ROBOT_YAML,
)
from capstone_pkg.utils.joint_limit import load_joint_limits_torch
from capstone_pkg.utils.jointstate_publisher import (
    publish_q_path_as_jointstate_keep_gripper_closed,
)


def _read_angular_z_from_cmd_vel(topic: str, timeout_sec: float) -> float:
    import rclpy
    from geometry_msgs.msg import Twist
    from rclpy.node import Node
    from rclpy.qos import qos_profile_sensor_data

    class _CmdVelReader(Node):
        def __init__(self) -> None:
            super().__init__("cart_cmd_vel_reader")
            self.latest = None
            self.sub = self.create_subscription(Twist, topic, self._cb, qos_profile_sensor_data)

        def _cb(self, msg: Twist) -> None:
            self.latest = float(msg.angular.z)

    created = False
    if not rclpy.ok():
        rclpy.init(args=None)
        created = True

    node = _CmdVelReader()
    try:
        t0 = time.time()
        while time.time() - t0 < float(timeout_sec):
            rclpy.spin_once(node, timeout_sec=0.05)
            if node.latest is not None:
                return float(node.latest)
    finally:
        node.destroy_node()
        if created:
            rclpy.shutdown()

    raise TimeoutError(f"cmd_vel angular.z를 못 받았습니다. topic={topic}")


def _compute_max_abs_joint_error(a: Sequence[float], b: Sequence[float]) -> float:
    dof = min(len(a), len(b))
    if dof <= 0:
        return math.inf
    return max(abs(float(a[i]) - float(b[i])) for i in range(dof))


def _select_profile_closest_to_q(
    profiles: Sequence[CartGoalProfile],
    q_target: Sequence[float],
) -> CartGoalProfile:
    if not profiles:
        raise ValueError("profiles is empty")
    return min(
        profiles,
        key=lambda profile: (
            _compute_max_abs_joint_error(profile.q_goal, q_target),
            abs(float(profile.angular_z)),
        ),
    )


def _try_direct_projected_path(
    *,
    q_start: Sequence[float],
    q_goals: Sequence[Sequence[float]],
    checker,
    projector: ManifoldProjector,
    robot_yml: str,
    world_yml: str | None,
    device: torch.device,
    direct_interp_steps: int,
    edge_step_q: float,
    edge_max_steps: int,
) -> tuple[List[List[float]] | None, int | None, str | None]:
    if direct_interp_steps < 1:
        return None, None, "direct_interp_steps must be >= 1"

    edge_checker = EdgeCollisionChecker(
        robot_yml=str(robot_yml),
        cpu=(device.type == "cpu"),
        world_yml=world_yml,
        step_q=float(edge_step_q),
        max_steps=int(edge_max_steps),
    )

    q_start_t = torch.tensor(q_start, device=device, dtype=torch.float32)
    pr_start = projector.project(q_start_t)
    if not pr_start.success:
        return None, None, "direct start projection failed"

    for goal_idx, q_goal in enumerate(q_goals):
        q_goal_t = torch.tensor(q_goal, device=device, dtype=torch.float32)
        pr_goal = projector.project(q_goal_t)
        if not pr_goal.success:
            continue

        t = torch.linspace(
            0.0,
            1.0,
            int(direct_interp_steps) + 1,
            device=device,
            dtype=torch.float32,
        ).unsqueeze(1)
        coarse_path = (1.0 - t) * pr_start.q_proj.unsqueeze(0) + t * pr_goal.q_proj.unsqueeze(0)

        try:
            path_proj = lazy_project_path(
                coarse_path,
                projector=projector,
                edge_checker=edge_checker,
                residual_accept_tol=float(projector.tol),
            )
        except RuntimeError as exc:
            continue

        free_mask = checker.get_collision_free_mask(path_proj, margin=0.0)
        if not bool(free_mask.all().item()):
            continue

        return path_to_list(path_proj), int(goal_idx), None

    return None, None, "no direct projected path candidate succeeded"


def build_cart_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile_json", type=str, required=True)
    ap.add_argument("--angular_z", type=float, default=None)
    ap.add_argument("--start_angular_z", type=float, default=None)
    ap.add_argument("--cmd_vel_topic", type=str, default="/cmd_vel")
    ap.add_argument("--cmd_vel_timeout_sec", type=float, default=3.0)
    ap.add_argument("--goal_candidates", type=int, default=1)
    ap.add_argument("--use_stored_trajectory", action=argparse.BooleanOptionalAction, default=False)
    ap.add_argument("--use_stored_transition_trajectory", action=argparse.BooleanOptionalAction, default=False)
    ap.add_argument("--stored_path_start_tol", type=float, default=0.25)
    ap.add_argument("--stored_transition_start_tol", type=float, default=0.25)
    ap.add_argument("--save_planned_trajectory_to_profile", action=argparse.BooleanOptionalAction, default=False)
    ap.add_argument("--save_planned_trajectory_to_transition", action=argparse.BooleanOptionalAction, default=False)
    ap.add_argument("--save_to_same_range_profiles", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument("--use_profile_q_ref", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument("--robot_yml", type=str, default=ROBOT_YAML)
    ap.add_argument("--world_yml", type=str, default=None, help="world collision yaml; None이면 world collision 비활성화")
    ap.add_argument("--joint_limit_yml", type=str, default=JOINT_LIMIT)
    ap.add_argument("--jointstate_topic", type=str, default="/joint_states")
    ap.add_argument("--jointstate_timeout_sec", type=float, default=5.0)
    ap.add_argument("--cmd_topic", type=str, default="/joint_states_cmd")
    ap.add_argument("--publish_mode", choices=("none", "joint_state", "real"), default="joint_state")
    ap.add_argument("--mujoco_xml", type=str, default=ROBOT_XML)
    ap.add_argument("--left_ee", type=str, default=LEFT_EE_FRAME)
    ap.add_argument("--right_ee", type=str, default=RIGHT_EE_FRAME)
    ap.add_argument(
        "--planar_xy",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="keep x-y planar motion: current left z and roll/pitch are preserved, yaw is allowed",
    )
    ap.add_argument("--rigid_orientation", action=argparse.BooleanOptionalAction, default=False)
    ap.add_argument("--lock_z", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument("--step_size", type=float, default=0.1)
    ap.add_argument("--goal_threshold", type=float, default=0.10)
    ap.add_argument("--EM", type=float, default=0.02)
    ap.add_argument("--E_conn", type=float, default=0.025)
    ap.add_argument("--ts_radius", type=float, default=1.1)
    ap.add_argument("--p_uniform", type=float, default=0.25)
    ap.add_argument("--goal_bias", type=float, default=0.15)
    ap.add_argument("--connect_max_steps", type=int, default=10)
    ap.add_argument("--escape_extend_steps", type=int, default=5)
    ap.add_argument("--max_iters", type=int, default=500000)
    ap.add_argument("--time_limit_sec", type=float, default=900.0)
    ap.add_argument("--proj_iters", type=int, default=60)
    ap.add_argument("--proj_tol", type=float, default=1e-3)
    ap.add_argument("--proj_fd_eps", type=float, default=1e-3)
    ap.add_argument("--try_direct_path_first", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument("--direct_interp_steps", type=int, default=12)
    ap.add_argument("--edge_step_q", type=float, default=0.03)
    ap.add_argument("--edge_max_steps", type=int, default=128)
    ap.add_argument("--svd_tol", type=float, default=1e-6)
    ap.add_argument("--device", type=str, default="cuda", choices=["cuda", "cpu"])
    ap.add_argument("--seed", type=int, default=-1)
    ap.add_argument("--hz", type=float, default=15.0)
    ap.add_argument("--repeat", type=int, default=1)
    ap.add_argument("--start_delay_s", type=float, default=0.2)
    ap.add_argument("--hold_last_s", type=float, default=0.0)
    ap.add_argument("--close_value", type=float, default=1.0)
    ap.add_argument("--real_left_topic", default="/leader/joint_trajectory_command_broadcaster_left/joint_trajectory")
    ap.add_argument("--real_right_topic", default="/leader/joint_trajectory_command_broadcaster_right/joint_trajectory")
    ap.add_argument("--real_left_gripper_topic", default="/leader/joint_trajectory_command_broadcaster_gripper_left/joint_trajectory")
    ap.add_argument("--real_right_gripper_topic", default="/leader/joint_trajectory_command_broadcaster_gripper_right/joint_trajectory")
    ap.add_argument("--real_use_action", action=argparse.BooleanOptionalAction, default=False)
    ap.add_argument("--real_action_fallback_to_topic", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument("--real_left_action", default="/leader/joint_trajectory_command_broadcaster_left/follow_joint_trajectory")
    ap.add_argument("--real_right_action", default="/leader/joint_trajectory_command_broadcaster_right/follow_joint_trajectory")
    ap.add_argument("--real_left_gripper_action", default="/leader/joint_trajectory_command_broadcaster_gripper_left/follow_joint_trajectory")
    ap.add_argument("--real_right_gripper_action", default="/leader/joint_trajectory_command_broadcaster_gripper_right/follow_joint_trajectory")
    ap.add_argument("--action_wait_server_s", type=float, default=2.0)
    ap.add_argument("--action_wait_result_s", type=float, default=-1.0)
    ap.add_argument("--publish_wait_subscriber_s", type=float, default=5.0)
    ap.add_argument("--publish_require_subscriber", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument("--publish_retry_until_subscriber", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument("--publish_repeat", type=int, default=2)
    ap.add_argument("--publish_period_s", type=float, default=0.05)
    ap.add_argument("--publish_wait_ack_s", type=float, default=1.0)
    ap.add_argument("--publish_keep_alive_s", type=float, default=0.5)
    ap.add_argument("--publish_transient_local", action=argparse.BooleanOptionalAction, default=False)
    ap.add_argument("--attach_object", action="store_true", default=False)
    return ap


def main_cart(argv: Sequence[str] | None = None) -> int:
    args = build_cart_parser().parse_args(list(argv) if argv is not None else None)
    t0 = time.time()
    device = torch.device("cuda") if (args.device == "cuda" and torch.cuda.is_available()) else torch.device("cpu")
    dtype = torch.float32

    if bool(args.use_stored_trajectory) and bool(args.use_stored_transition_trajectory):
        raise ValueError("--use_stored_trajectory and --use_stored_transition_trajectory cannot both be enabled")

    library = load_cart_goal_library(str(args.profile_json))

    if args.angular_z is None:
        requested_angular_z = _read_angular_z_from_cmd_vel(
            topic=str(args.cmd_vel_topic),
            timeout_sec=float(args.cmd_vel_timeout_sec),
        )
    else:
        requested_angular_z = float(args.angular_z)

    selected_profiles, clamped_angular_z = select_cart_goal_profiles(
        library,
        requested_angular_z,
        count=max(1, int(args.goal_candidates)),
    )
    for line in describe_selected_profiles(
        selected_profiles,
        requested_angular_z=requested_angular_z,
        clamped_angular_z=clamped_angular_z,
    ):
        print(f"[cart] {line}")

    selected_start_profile: CartGoalProfile | None = None
    selected_start_clamped_angular_z: float | None = None
    if args.start_angular_z is None:
        q_start = get_q_start_from_jointstate(
            topic=str(args.jointstate_topic),
            joint_names=list(library.cspace_joint_names),
            timeout_sec=float(args.jointstate_timeout_sec),
        )
        print("[cart] q_start(current) =", q_start)
    else:
        start_profiles, selected_start_clamped_angular_z = select_cart_goal_profiles(
            library,
            float(args.start_angular_z),
            count=1,
        )
        selected_start_profile = start_profiles[0]
        q_start = [float(v) for v in selected_start_profile.q_goal]
        print(
            "[cart] q_start(profile override) = {} "
            "(requested={:.6f}, clamped={:.6f}, range_label={})".format(
                q_start,
                float(args.start_angular_z),
                float(selected_start_clamped_angular_z),
                get_profile_range_label(selected_start_profile),
            )
        )
        if args.publish_mode != "none":
            print("[cart][WARN] --start_angular_z is set, so the planner start state comes from profile q_goal, not live /joint_states.")

    q_goals = [[float(v) for v in profile.q_goal] for profile in selected_profiles]
    selected_goal_profile = selected_profiles[0]

    resolved_start_profile: CartGoalProfile | None = selected_start_profile
    resolved_start_profile_max_abs_err = 0.0
    resolved_start_profile_l2_err = 0.0

    def _ensure_start_profile(require_match_tol: float | None) -> CartGoalProfile:
        nonlocal resolved_start_profile
        nonlocal resolved_start_profile_max_abs_err
        nonlocal resolved_start_profile_l2_err

        if resolved_start_profile is not None:
            return resolved_start_profile

        inferred_profile, max_abs_err, l2_err = infer_start_profile_from_q(library, q_start)
        print(
            "[cart] inferred start profile: angular.z={:.6f} range_label={} max_abs_err={:.6f} l2_err={:.6f}".format(
                float(inferred_profile.angular_z),
                get_profile_range_label(inferred_profile),
                float(max_abs_err),
                float(l2_err),
            )
        )
        if require_match_tol is not None and max_abs_err > float(require_match_tol):
            raise RuntimeError(
                "current q_start does not match a stored start profile closely enough: "
                f"{max_abs_err:.6f} > {float(require_match_tol):.6f}"
            )
        resolved_start_profile = inferred_profile
        resolved_start_profile_max_abs_err = float(max_abs_err)
        resolved_start_profile_l2_err = float(l2_err)
        return resolved_start_profile

    path_rows: List[List[float]]
    if bool(args.use_stored_transition_trajectory):
        start_profile = _ensure_start_profile(float(args.stored_transition_start_tol))
        transition = find_stored_transition(
            library,
            start_range_label=get_profile_range_label(start_profile),
            goal_range_label=get_profile_range_label(selected_goal_profile),
        )
        if transition is None:
            raise RuntimeError(
                "stored transition not found for {} -> {}".format(
                    get_profile_range_label(start_profile),
                    get_profile_range_label(selected_goal_profile),
                )
            )
        path_rows = [[float(v) for v in row] for row in transition.q_path]
        max_abs_start_err = _compute_max_abs_joint_error(path_rows[0], q_start)
        print("\n[cart] USING STORED TRANSITION TRAJECTORY")
        print(
            "  {} -> {} label={}".format(
                str(transition.start_range_label),
                str(transition.goal_range_label),
                transition.label if transition.label else "(none)",
            )
        )
        print(f"  path_len={len(path_rows)}")
        print(f"  stored_transition_start_max_abs_err={max_abs_start_err:.6f}")
        if max_abs_start_err > float(args.stored_transition_start_tol):
            raise RuntimeError(
                "stored transition trajectory start is too far from current/planned state: "
                f"{max_abs_start_err:.6f} > {float(args.stored_transition_start_tol):.6f}"
            )
    elif bool(args.use_stored_trajectory):
        profile = selected_profiles[0]
        if not profile.q_path:
            raise RuntimeError("selected profile has no stored q_path")
        path_rows = [[float(v) for v in row] for row in profile.q_path]
        max_abs_start_err = _compute_max_abs_joint_error(path_rows[0], q_start)
        print("\n[cart] USING STORED TRAJECTORY")
        print(f"  path_len={len(path_rows)}")
        print(f"  stored_path_start_max_abs_err={max_abs_start_err:.6f}")
        if max_abs_start_err > float(args.stored_path_start_tol):
            raise RuntimeError(
                "stored trajectory start is too far from current state: "
                f"{max_abs_start_err:.6f} > {float(args.stored_path_start_tol):.6f}"
            )
    else:
        _world_yml = None if args.world_yml in (None, "", "none", "None") else str(args.world_yml)
        checker = get_self_collision_checker(str(args.robot_yml), cpu=(device.type == "cpu"), world_yml=_world_yml)

        if bool(args.attach_object):
            if not hasattr(checker, "_build_q_active_from_cspace"):
                raise RuntimeError("SelfCollisionChecker has no _build_q_active_from_cspace()")
            q_start_c = torch.tensor(q_start, device=device, dtype=torch.float32).view(1, -1)
            q_model = checker._build_q_active_from_cspace(q_start_c)[0]
            checker.attach_mujoco_object_to_robot(
                mujoco_xml_path=str(args.mujoco_xml),
                q_model_order=q_model,
                link_name=str(args.left_ee),
                name_prefix="att_",
                disable_in_world=False,
            )
            print("[cart] attached mujoco object to robot")

        jl = load_joint_limits_torch(str(args.joint_limit_yml), device=device, dtype=dtype)
        if args.start_angular_z is not None:
            q_constraint_ref = [float(v) for v in q_start]
            if bool(args.use_profile_q_ref):
                print(
                    "[cart] start_angular_z override active: using q_start as constraint reference "
                    "to preserve the selected start-profile z/roll/pitch"
                )
        else:
            q_constraint_ref = (
                [float(v) for v in library.q_reference_cspace]
                if bool(args.use_profile_q_ref)
                else [float(v) for v in q_start]
            )
        q_ref = torch.tensor(q_constraint_ref, device=device, dtype=dtype)
        lock_z = bool(args.lock_z or args.planar_xy)

        print("[cart] q_ref(constraint) =", q_constraint_ref)
        if bool(args.planar_xy):
            print("[cart] planar_xy enabled: enforcing left z lock and yaw-only absolute rotation")
        if bool(args.planar_xy) and bool(args.rigid_orientation):
            print("[cart][WARN] rigid_orientation is also enabled, so yaw will be locked too.")

        constraint = RigidConstraint(
            robot_yml=str(args.robot_yml),
            left_ee=str(args.left_ee),
            right_ee=str(args.right_ee),
            q_ref=q_ref,
            device=device,
            dtype=dtype,
            mode="se3",
            rigid_orientation=bool(args.rigid_orientation),
            lock_z=lock_z,
            planar_xy=bool(args.planar_xy),
        )
        projector = ManifoldProjector(
            constraint=constraint,
            limits=jl,
            max_iters=int(args.proj_iters),
            tol=float(args.proj_tol),
            fd_eps=float(args.proj_fd_eps),
        )

        cfg = TBRRTConfig(
            step_size=float(args.step_size),
            goal_threshold=float(args.goal_threshold),
            EM=float(args.EM),
            E_conn=float(args.E_conn),
            ts_radius=float(args.ts_radius),
            p_uniform=float(args.p_uniform),
            goal_bias=float(args.goal_bias),
            connect_max_steps=int(args.connect_max_steps),
            escape_extend_steps=max(1, int(args.escape_extend_steps)),
            max_iters=int(args.max_iters),
            time_limit_sec=float(args.time_limit_sec),
            edge_step_q=float(args.edge_step_q),
            edge_max_steps=int(args.edge_max_steps),
            svd_tol=float(args.svd_tol),
            seed=(None if int(args.seed) < 0 else int(args.seed)),
        )

        path_rows = None
        chosen_goal_idx = 0
        if bool(args.try_direct_path_first):
            direct_path_rows, direct_goal_idx, direct_reason = _try_direct_projected_path(
                q_start=q_start,
                q_goals=q_goals,
                checker=checker,
                projector=projector,
                robot_yml=str(args.robot_yml),
                world_yml=_world_yml,
                device=device,
                direct_interp_steps=int(args.direct_interp_steps),
                edge_step_q=float(args.edge_step_q),
                edge_max_steps=int(args.edge_max_steps),
            )
            if direct_path_rows is not None:
                path_rows = [[float(v) for v in row] for row in direct_path_rows]
                chosen_goal_idx = int(direct_goal_idx or 0)
                print("\n[cart] SUCCESS (direct projected path)")
                print(f"  direct_interp_steps={int(args.direct_interp_steps)}")
                print(f"  matched_goal_idx={chosen_goal_idx}")
                print(f"  path_len={len(path_rows)}")
            else:
                print(f"[cart] direct projected path unavailable: {direct_reason}")

        if path_rows is None:
            out = plan_tbrrt_extcon(
                q_start=q_start,
                q_goals=q_goals,
                cfg=cfg,
                checker=checker,
                projector=projector,
                joint_limits=jl,
                device=device,
            )
            if not out.success:
                print(f"[cart] planning failed: {out.stats.extra}")
                print(f"[cart] total wall time = {time.time() - t0:.3f}s")
                return 1

            print("\n[cart] SUCCESS")
            print(
                "  iters={} nodesA={} nodesB={} ts={} time={:.3f}s".format(
                    out.stats.iters,
                    out.stats.nodes_A,
                    out.stats.nodes_B,
                    out.stats.ts_count,
                    out.stats.time_sec,
                )
            )
            if out.path is not None:
                print(f"  path_len={len(out.path)}")
            path_rows = [[float(v) for v in row] for row in out.path]
            chosen_goal_idx = int(out.stats.extra.get("matched_goal_idx", 0)) if isinstance(out.stats.extra, dict) else 0
        if bool(args.save_planned_trajectory_to_profile):
            arrived_goal_profile = selected_profiles[min(max(int(chosen_goal_idx), 0), len(selected_profiles) - 1)]
            selected_profile = arrived_goal_profile
            selected_range_label = str(selected_profile.metadata.get("selected_range_label", ""))
            updated = 0
            for profile in library.profiles:
                same_profile = math.isclose(float(profile.angular_z), float(selected_profile.angular_z), abs_tol=1.0e-9)
                same_range = (
                    bool(args.save_to_same_range_profiles)
                    and selected_range_label
                    and str(profile.metadata.get("selected_range_label", "")) == selected_range_label
                )
                if same_profile or same_range:
                    profile.q_path = [[float(v) for v in row] for row in path_rows]
                    updated += 1
            save_cart_goal_library(str(args.profile_json), library)
            print(f"[cart] saved planned trajectory into {updated} profile(s): {args.profile_json}")
        if bool(args.save_planned_trajectory_to_transition):
            start_profile = _ensure_start_profile(float(args.stored_transition_start_tol))
            arrived_goal_profile = selected_profiles[min(max(int(chosen_goal_idx), 0), len(selected_profiles) - 1)]
            transition = CartStoredTransition(
                start_angular_z=float(get_profile_anchor_angular_z(start_profile)),
                goal_angular_z=float(get_profile_anchor_angular_z(arrived_goal_profile)),
                start_range_label=str(get_profile_range_label(start_profile)),
                goal_range_label=str(get_profile_range_label(arrived_goal_profile)),
                q_path=[[float(v) for v in row] for row in path_rows],
                label="{}_to_{}".format(
                    str(get_profile_range_label(start_profile)),
                    str(get_profile_range_label(arrived_goal_profile)),
                ),
                metadata={
                    "requested_goal_angular_z": float(requested_angular_z),
                    "clamped_goal_angular_z": float(clamped_angular_z),
                    "start_profile_angular_z": float(start_profile.angular_z),
                    "goal_profile_angular_z": float(arrived_goal_profile.angular_z),
                    "start_profile_match_max_abs_err": float(resolved_start_profile_max_abs_err),
                    "start_profile_match_l2_err": float(resolved_start_profile_l2_err),
                },
            )
            action = upsert_stored_transition(library, transition)
            save_cart_goal_library(str(args.profile_json), library)
            print(
                "[cart] {} stored transition {} -> {} : {}".format(
                    action,
                    transition.start_range_label,
                    transition.goal_range_label,
                    args.profile_json,
                )
            )

    traj_dt = 1.0 / max(1e-6, float(args.hz))
    left_dof = len(LEFT_JOINTS)
    left_path = [row[:left_dof] for row in path_rows]
    right_path = [row[left_dof:] for row in path_rows]

    def _send_real_commands(
        *,
        topic_commands: list[JointTrajectoryCommand],
        action_commands: list[JointTrajectoryCommand],
        dt: float,
        start_time_delay_s: float,
        label: str,
    ) -> str:
        if args.real_use_action:
            try:
                action_targets = ", ".join(cmd.endpoint for cmd in action_commands)
                print(
                    f"[{label}] Sending FollowJointTrajectory -> {action_targets} "
                    f"(dt={dt:.3f}s)"
                )
                send_joint_trajectory_action_group(
                    action_commands,
                    dt=dt,
                    wait_server_s=float(args.action_wait_server_s),
                    wait_result_s=float(args.action_wait_result_s),
                    start_time_delay_s=float(start_time_delay_s),
                )
                return "action"
            except RuntimeError as exc:
                print(f"[ACTION] {exc}")
                if not args.real_action_fallback_to_topic:
                    raise
                topic_targets = ", ".join(cmd.endpoint for cmd in topic_commands)
                print(f"[ACTION] Falling back to JointTrajectory topics -> {topic_targets}")

        topic_targets = ", ".join(cmd.endpoint for cmd in topic_commands)
        print(f"[{label}] Publishing JointTrajectory -> {topic_targets} (dt={dt:.3f}s)")
        publish_joint_trajectory_group(
            topic_commands,
            dt=dt,
            wait_subscriber_s=float(args.publish_wait_subscriber_s),
            require_subscriber=bool(args.publish_require_subscriber),
            retry_until_subscriber=bool(args.publish_retry_until_subscriber),
            publish_repeat=int(args.publish_repeat),
            publish_period_s=float(args.publish_period_s),
            wait_ack_s=float(args.publish_wait_ack_s),
            keep_alive_s=float(args.publish_keep_alive_s),
            transient_local=bool(args.publish_transient_local),
            start_time_delay_s=float(start_time_delay_s),
        )
        return "topic"

    if args.publish_mode == "real":
        arm_topic_commands = [
            JointTrajectoryCommand(
                endpoint=str(args.real_left_topic),
                joint_names=list(LEFT_JOINTS),
                path=left_path,
            ),
            JointTrajectoryCommand(
                endpoint=str(args.real_right_topic),
                joint_names=list(RIGHT_JOINTS),
                path=right_path,
            ),
        ]
        arm_action_commands = [
            JointTrajectoryCommand(
                endpoint=str(args.real_left_action),
                joint_names=list(LEFT_JOINTS),
                path=left_path,
            ),
            JointTrajectoryCommand(
                endpoint=str(args.real_right_action),
                joint_names=list(RIGHT_JOINTS),
                path=right_path,
            ),
        ]
        _send_real_commands(
            topic_commands=arm_topic_commands,
            action_commands=arm_action_commands,
            dt=traj_dt,
            start_time_delay_s=float(args.start_delay_s),
            label="REAL",
        )
    elif args.publish_mode == "joint_state":
        q_path = torch.tensor(path_rows, device=device, dtype=dtype)
        publish_q_path_as_jointstate_keep_gripper_closed(
            q_path=q_path,
            robot_yml=str(args.robot_yml),
            mujoco_xml=str(args.mujoco_xml),
            close_value=float(args.close_value),
            cmd_topic=str(args.cmd_topic),
            hz=float(args.hz),
            repeat=int(args.repeat),
            start_delay_s=float(args.start_delay_s),
            hold_last_s=float(args.hold_last_s),
            node_name="cart_tbrrt_path_publisher",
        )
    else:
        print("[cart] publish_mode=none: skipping command publish")

    print("  q_start(path) =", path_rows[0])
    print("  q_goal(path)  =", path_rows[-1])
    print(f"[cart] total wall time = {time.time() - t0:.3f}s")
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    return main_cart(argv)


if __name__ == "__main__":
    raise SystemExit(main())
