from __future__ import annotations

import argparse
import math
from typing import Any, Dict, List, Sequence, Tuple

import numpy as np
import torch

from capstone_pkg.constraint_projection.constraint import (
    RigidConstraint,
    build_bimanual_fk_robotworld,
)
from capstone_pkg.collision_check.collision import get_self_collision_checker
from capstone_pkg.kinematics.curobo_ik import SingleArmIK
from capstone_pkg.planner.cart.profiles import (
    CartGoalLibrary,
    CartGoalProfile,
    angular_z_to_ratio,
    save_cart_goal_library,
)
from capstone_pkg.planner.start_goal import (
    euler_rpy_deg_to_quat_wxyz,
    get_q_start_from_jointstate,
    quat_wxyz_to_euler_rpy_deg,
)
from capstone_pkg.utils.config import (
    CSPACE_JOINT_NAMES_14,
    JOINT_LIMIT,
    LEFT_EE_FRAME,
    RIGHT_EE_FRAME,
    ROBOT_URDF,
    ROBOT_YAML,
    WORLD_YAML,
)
from capstone_pkg.utils.joint_limit import load_joint_limits_torch


def _quat_conj_wxyz(q: Sequence[float]) -> List[float]:
    return [float(q[0]), -float(q[1]), -float(q[2]), -float(q[3])]


def _quat_mul_wxyz(a: Sequence[float], b: Sequence[float]) -> List[float]:
    aw, ax, ay, az = [float(v) for v in a]
    bw, bx, by, bz = [float(v) for v in b]
    return [
        aw * bw - ax * bx - ay * by - az * bz,
        aw * bx + ax * bw + ay * bz - az * by,
        aw * by - ax * bz + ay * bw + az * bx,
        aw * bz + ax * by - ay * bx + az * bw,
    ]


def _quat_normalize_wxyz(q: Sequence[float]) -> List[float]:
    q_list = [float(v) for v in q]
    n2 = sum(v * v for v in q_list)
    if n2 < 1.0e-18:
        return [1.0, 0.0, 0.0, 0.0]
    inv = 1.0 / math.sqrt(n2)
    return [v * inv for v in q_list]


def _quat_rotate_wxyz(q: Sequence[float], v: Sequence[float]) -> List[float]:
    qn = _quat_normalize_wxyz(q)
    vq = [0.0, float(v[0]), float(v[1]), float(v[2])]
    out = _quat_mul_wxyz(_quat_mul_wxyz(qn, vq), _quat_conj_wxyz(qn))
    return [float(out[1]), float(out[2]), float(out[3])]


def _quat_make_continuous_w_pos_w(q: Sequence[float]) -> List[float]:
    q_list = [float(v) for v in q]
    if q_list[0] < 0.0:
        return [-v for v in q_list]
    return q_list


def _wrapped_joint_delta(a: float, b: float) -> float:
    return abs(math.atan2(math.sin(float(a) - float(b)), math.cos(float(a) - float(b))))


def _joint_distance_metrics(q_a: Sequence[float], q_b: Sequence[float]) -> Tuple[float, float]:
    dof = min(len(q_a), len(q_b))
    if dof <= 0:
        return math.inf, math.inf
    deltas = [_wrapped_joint_delta(float(q_a[i]), float(q_b[i])) for i in range(dof)]
    max_abs = max(deltas)
    l2 = math.sqrt(sum(delta * delta for delta in deltas))
    return float(max_abs), float(l2)


def _build_curobo_seed_batch(
    *,
    anchor_q: Sequence[float],
    seed_candidates: Sequence[Tuple[str, Sequence[float]]],
    num_trials: int,
    noise_std: float,
    random_seed: int,
    lower: np.ndarray,
    upper: np.ndarray,
) -> List[Tuple[str, List[float]]]:
    if int(num_trials) <= 0:
        raise ValueError("num_trials must be > 0")

    seeds: List[Tuple[str, List[float]]] = []
    seen = set()

    def _add_seed(label: str, q_seed: Sequence[float]) -> None:
        q_list = [float(v) for v in q_seed]
        key = tuple(round(v, 6) for v in q_list)
        if key in seen:
            return
        seen.add(key)
        seeds.append((str(label), q_list))

    for label, q_seed in seed_candidates:
        _add_seed(str(label), q_seed)

    rng = np.random.default_rng(int(random_seed))
    q_anchor = np.asarray(anchor_q, dtype=np.float64)
    while len(seeds) < int(num_trials):
        if float(noise_std) <= 0.0:
            break
        q_seed = q_anchor + rng.normal(loc=0.0, scale=float(noise_std), size=q_anchor.shape)
        q_seed = np.clip(q_seed, lower, upper)
        _add_seed("noise", q_seed.tolist())

    if not seeds:
        _add_seed("anchor", anchor_q)
    return seeds[: max(1, int(num_trials))]


def _build_uniform_angular_bins(*, max_abs_angular_z: float, angular_step: float) -> List[float]:
    max_abs = float(max_abs_angular_z)
    step = float(angular_step)
    if max_abs <= 0.0:
        raise ValueError("max_abs_angular_z must be > 0")
    if step <= 0.0:
        raise ValueError("angular_step must be > 0")

    span = 2.0 * max_abs
    steps = int(math.floor((span / step) + 1.0e-9))
    bins = [round(-max_abs + (idx * step), 10) for idx in range(steps + 1)]
    if not bins or not math.isclose(bins[-1], max_abs, abs_tol=1.0e-9):
        bins.append(round(max_abs, 10))
    return bins


def _resolve_angular_bins(
    angular_bins: Sequence[float] | None,
    *,
    max_abs_angular_z: float,
    angular_step: float,
) -> List[float]:
    if angular_bins:
        return [float(v) for v in angular_bins]
    return _build_uniform_angular_bins(
        max_abs_angular_z=float(max_abs_angular_z),
        angular_step=float(angular_step),
    )


_DISCRETE_PLANAR_TARGETS: Tuple[Dict[str, Any], ...] = (
    {
        "label": "neg_hard",
        "anchor_angular_z": -1.5,
        "range_min_angular_z": -1.5,
        "range_max_angular_z": -0.8,
        "target_x_m": 0.45,
        "target_yaw_deg": 70.0,
    },
    {
        "label": "neg_mid",
        "anchor_angular_z": -0.7,
        "range_min_angular_z": -0.7,
        "range_max_angular_z": -0.3,
        "target_x_m": 0.45,
        "target_yaw_deg": 80.0,
    },
    {
        "label": "center",
        "anchor_angular_z": 0.0,
        "range_min_angular_z": -0.2,
        "range_max_angular_z": 0.2,
        "target_x_m": 0.4,
        "target_yaw_deg": 90.0,
    },
    {
        "label": "pos_mid",
        "anchor_angular_z": 0.7,
        "range_min_angular_z": 0.3,
        "range_max_angular_z": 0.7,
        "target_x_m": 0.35,
        "target_yaw_deg": 100.0,
    },
    {
        "label": "pos_hard",
        "anchor_angular_z": 1.5,
        "range_min_angular_z": 0.8,
        "range_max_angular_z": 1.5,
        "target_x_m": 0.35,
        "target_yaw_deg": 110.0,
    },
)


def _build_discrete_planar_target_ranges(*, max_abs_angular_z: float) -> List[Dict[str, Any]]:
    max_abs = float(max_abs_angular_z)
    if max_abs <= 0.0:
        raise ValueError("max_abs_angular_z must be > 0")

    if not _DISCRETE_PLANAR_TARGETS:
        raise ValueError("discrete planar targets are empty")

    specs: List[Dict[str, Any]] = []
    for item in _DISCRETE_PLANAR_TARGETS:
        range_min = float(item["range_min_angular_z"])
        range_max = float(item["range_max_angular_z"])
        anchor = float(item["anchor_angular_z"])
        if range_min > range_max:
            raise ValueError(f"invalid discrete target range: {item}")
        if abs(anchor) > max_abs + 1.0e-9:
            raise ValueError("discrete planar target anchors exceed max_abs_angular_z")
        if range_min < (-max_abs - 1.0e-9) or range_max > (max_abs + 1.0e-9):
            raise ValueError("discrete planar target ranges exceed max_abs_angular_z")
        specs.append(
            {
                **item,
                "range_min_angular_z": float(range_min),
                "range_max_angular_z": float(range_max),
            }
        )
    return specs


def _select_discrete_left_target(
    *,
    angular_z: float,
    max_abs_angular_z: float,
) -> Dict[str, Any]:
    z = max(-float(max_abs_angular_z), min(float(max_abs_angular_z), float(angular_z)))
    specs = _build_discrete_planar_target_ranges(max_abs_angular_z=float(max_abs_angular_z))
    for spec in specs:
        if (
            float(spec["range_min_angular_z"]) - 1.0e-9
            <= z
            <= float(spec["range_max_angular_z"]) + 1.0e-9
        ):
            return dict(spec)

    return dict(
        min(
            specs,
            key=lambda spec: min(
                abs(z - float(spec["range_min_angular_z"])),
                abs(z - float(spec["range_max_angular_z"])),
            ),
        )
    )


def build_planar_left_target(
    *,
    angular_z: float,
    max_abs_angular_z: float,
    left_target_y_m: float,
    left_target_z_m: float,
    left_target_roll_deg: float,
    left_target_pitch_deg: float,
) -> Tuple[List[float], List[float], Dict[str, Any]]:
    target_spec = _select_discrete_left_target(
        angular_z=float(angular_z),
        max_abs_angular_z=float(max_abs_angular_z),
    )
    ratio = angular_z_to_ratio(float(angular_z), float(max_abs_angular_z))
    target_x = float(target_spec["target_x_m"])
    target_yaw_deg = float(target_spec["target_yaw_deg"])
    range_label = str(target_spec["label"])
    range_min = float(target_spec["range_min_angular_z"])
    range_max = float(target_spec["range_max_angular_z"])
    anchor_angular_z = float(target_spec["anchor_angular_z"])

    target_xyz = [
        float(target_x),
        float(left_target_y_m),
        float(left_target_z_m),
    ]
    target_rpy_deg = [
        float(left_target_roll_deg),
        float(left_target_pitch_deg),
        float(target_yaw_deg),
    ]
    target_quat = euler_rpy_deg_to_quat_wxyz(
        target_rpy_deg[0],
        target_rpy_deg[1],
        target_rpy_deg[2],
    )
    metadata = {
        "selected_range_label": str(range_label),
        "selected_range_min_angular_z": float(range_min),
        "selected_range_max_angular_z": float(range_max),
        "selected_anchor_angular_z": float(anchor_angular_z),
        "requested_angular_z": float(angular_z),
        "ratio": float(ratio),
        "target_x_m": float(target_x),
        "target_y_m": float(target_xyz[1]),
        "target_z_m": float(target_xyz[2]),
        "target_yaw_deg": float(target_yaw_deg),
        "target_roll_deg": float(target_rpy_deg[0]),
        "target_pitch_deg": float(target_rpy_deg[1]),
    }
    return target_xyz, target_quat, metadata


def build_right_target_from_reference_relation(
    *,
    left_target_xyz: Sequence[float],
    left_target_quat_wxyz: Sequence[float],
    p_rel_ref: Sequence[float],
    q_rel_ref: Sequence[float],
) -> Tuple[List[float], List[float]]:
    rot_p = _quat_rotate_wxyz(left_target_quat_wxyz, p_rel_ref)
    right_xyz = [
        float(left_target_xyz[0]) + rot_p[0],
        float(left_target_xyz[1]) + rot_p[1],
        float(left_target_xyz[2]) + rot_p[2],
    ]
    right_quat = _quat_mul_wxyz(left_target_quat_wxyz, q_rel_ref)
    right_quat = _quat_make_continuous_w_pos_w(_quat_normalize_wxyz(right_quat))
    return right_xyz, right_quat


def build_cart_goal_library(
    *,
    robot_yml: str,
    urdf_path: str,
    world_yml: str | None,
    jointstate_topic: str,
    angular_bins: Sequence[float],
    max_abs_angular_z: float,
    left_target_y_m: float,
    left_target_z_m: float,
    left_target_roll_deg: float,
    left_target_pitch_deg: float,
    left_ee: str,
    right_ee: str,
    device_str: str,
    ik_num_seeds: int,
    ik_num_trials: int,
    ik_seed_noise_std: float,
    ik_random_seed: int,
    joint_limit_yml: str,
    forward_direction_base: Sequence[float],
    jointstate_timeout_sec: float,
) -> CartGoalLibrary:
    device = torch.device("cuda") if (device_str == "cuda" and torch.cuda.is_available()) else torch.device("cpu")
    q_reference = get_q_start_from_jointstate(
        topic=str(jointstate_topic),
        joint_names=list(CSPACE_JOINT_NAMES_14),
        timeout_sec=float(jointstate_timeout_sec),
    )
    print("[cart_profile] q_reference_cspace =", q_reference)

    fk = build_bimanual_fk_robotworld(
        robot_yml=str(robot_yml),
        left_ee=str(left_ee),
        right_ee=str(right_ee),
        device=device,
        dtype=torch.float32,
    )
    q_ref_t = torch.tensor(q_reference, device=device, dtype=torch.float32).view(1, -1)
    p_left, q_left = fk.fk_left_pose(q_ref_t)
    reference_left_xyz = [float(v) for v in p_left.squeeze(0).detach().cpu().tolist()]
    reference_left_quat = [float(v) for v in q_left.squeeze(0).detach().cpu().tolist()]

    print("[cart_profile] reference left xyz =", [round(v, 6) for v in reference_left_xyz])
    print("[cart_profile] reference left rpy =", [round(v, 6) for v in quat_wxyz_to_euler_rpy_deg(reference_left_quat)])

    constraint = RigidConstraint(
        robot_yml=str(robot_yml),
        left_ee=str(left_ee),
        right_ee=str(right_ee),
        q_ref=torch.tensor(q_reference, device=device, dtype=torch.float32),
        device=device,
        dtype=torch.float32,
        mode="se3",
    )
    p_rel_ref = [float(v) for v in constraint.p_rel_ref.detach().cpu().tolist()]
    q_rel_ref = [float(v) for v in constraint.q_rel_ref.detach().cpu().tolist()]

    left_solver = SingleArmIK(
        robot_yml=str(robot_yml),
        arm="left",
        cpu=(device.type == "cpu"),
        num_seeds=int(ik_num_seeds),
        world_yml=(None if world_yml in (None, "", "none", "None") else str(world_yml)),
    )
    right_solver = SingleArmIK(
        robot_yml=str(robot_yml),
        arm="right",
        cpu=(device.type == "cpu"),
        num_seeds=int(ik_num_seeds),
        world_yml=(None if world_yml in (None, "", "none", "None") else str(world_yml)),
    )
    checker = get_self_collision_checker(
        str(robot_yml),
        cpu=(device.type == "cpu"),
        world_yml=(None if world_yml in (None, "", "none", "None") else str(world_yml)),
    )
    print("[cart_profile] plain cuRobo IK mode = single-arm serial solve (left -> right)")
    jl = load_joint_limits_torch(str(joint_limit_yml), device=device, dtype=torch.float32)
    lower = jl.lower.detach().cpu().numpy().astype(np.float64, copy=False)
    upper = jl.upper.detach().cpu().numpy().astype(np.float64, copy=False)

    target_specs_by_label: Dict[str, Dict[str, Any]] = {}
    for angular_z in angular_bins:
        left_xyz, left_quat, target_meta = build_planar_left_target(
            angular_z=float(angular_z),
            max_abs_angular_z=float(max_abs_angular_z),
            left_target_y_m=float(left_target_y_m),
            left_target_z_m=float(left_target_z_m),
            left_target_roll_deg=float(left_target_roll_deg),
            left_target_pitch_deg=float(left_target_pitch_deg),
        )
        right_xyz, right_quat = build_right_target_from_reference_relation(
            left_target_xyz=left_xyz,
            left_target_quat_wxyz=left_quat,
            p_rel_ref=p_rel_ref,
            q_rel_ref=q_rel_ref,
        )
        range_label = str(target_meta["selected_range_label"])
        range_center = 0.5 * (
            float(target_meta["selected_range_min_angular_z"])
            + float(target_meta["selected_range_max_angular_z"])
        )
        spec = target_specs_by_label.get(range_label)
        if spec is None:
            target_specs_by_label[range_label] = {
                "range_label": range_label,
                "range_center": float(range_center),
                "left_xyz": [float(v) for v in left_xyz],
                "left_quat": [float(v) for v in left_quat],
                "right_xyz": [float(v) for v in right_xyz],
                "right_quat": [float(v) for v in right_quat],
                "target_meta": dict(target_meta),
            }

    target_specs = sorted(
        target_specs_by_label.values(),
        key=lambda item: (abs(float(item["range_center"])), float(item["range_center"])),
    )

    solved_by_label: Dict[str, Dict[str, Any]] = {}
    solved_specs: List[Dict[str, Any]] = []
    for spec in target_specs:
        continuity_target_label = "reference"
        continuity_target_q = [float(v) for v in q_reference]
        if solved_specs:
            nearest_solved = min(
                solved_specs,
                key=lambda item: abs(float(item["range_center"]) - float(spec["range_center"])),
            )
            continuity_target_label = str(nearest_solved["range_label"])
            continuity_target_q = [float(v) for v in nearest_solved["q_goal"]]

        seed_candidates: List[Tuple[str, List[float]]] = [
            (str(continuity_target_label), [float(v) for v in continuity_target_q]),
            ("reference", [float(v) for v in q_reference]),
        ]
        if solved_specs:
            for seed_spec in sorted(
                solved_specs,
                key=lambda item: abs(float(item["range_center"]) - float(spec["range_center"])),
            ):
                seed_candidates.append(
                    (
                        str(seed_spec["range_label"]),
                        [float(v) for v in seed_spec["q_goal"]],
                    )
                )

        q_seed_batch_labeled = _build_curobo_seed_batch(
            anchor_q=continuity_target_q,
            seed_candidates=seed_candidates,
            num_trials=int(ik_num_trials),
            noise_std=float(ik_seed_noise_std),
            random_seed=int(ik_random_seed),
            lower=lower,
            upper=upper,
        )
        best_candidate = None
        tried_seed_labels: List[str] = []
        for seed_label, q_seed in q_seed_batch_labeled:
            tried_seed_labels.append(str(seed_label))
            print(
                "[cart_profile] solving IK for range={} seed={} left_xyz={} left_rpy={}".format(
                    str(spec["range_label"]),
                    str(seed_label),
                    [round(v, 6) for v in spec["left_xyz"]],
                    [round(v, 6) for v in quat_wxyz_to_euler_rpy_deg(spec["left_quat"])],
                )
            )
            left_out = left_solver.solve(
                xyz=[float(v) for v in spec["left_xyz"]],
                quat_wxyz=[float(v) for v in spec["left_quat"]],
                q_start_cspace=[float(v) for v in q_seed],
            )
            if not left_out.success or left_out.q_cspace is None:
                continue
            ik_out = right_solver.solve(
                xyz=[float(v) for v in spec["right_xyz"]],
                quat_wxyz=[float(v) for v in spec["right_quat"]],
                q_start_cspace=[float(v) for v in left_out.q_cspace],
            )
            if not ik_out.success or ik_out.q_cspace is None:
                continue
            in_col, _, _ = checker.check_single(ik_out.q_cspace)
            if in_col:
                continue
            continuity_max_abs, continuity_l2 = _joint_distance_metrics(
                ik_out.q_cspace,
                continuity_target_q,
            )
            seed_max_abs, seed_l2 = _joint_distance_metrics(
                ik_out.q_cspace,
                q_seed,
            )
            candidate = {
                "ik_out": ik_out,
                "seed_label": str(seed_label),
                "continuity_max_abs": float(continuity_max_abs),
                "continuity_l2": float(continuity_l2),
                "seed_max_abs": float(seed_max_abs),
                "seed_l2": float(seed_l2),
            }
            if best_candidate is None or (
                (
                    candidate["continuity_max_abs"],
                    candidate["continuity_l2"],
                    candidate["seed_max_abs"],
                    candidate["seed_l2"],
                )
                < (
                    best_candidate["continuity_max_abs"],
                    best_candidate["continuity_l2"],
                    best_candidate["seed_max_abs"],
                    best_candidate["seed_l2"],
                )
            ):
                best_candidate = candidate

        if best_candidate is None:
            raise RuntimeError(
                "plain cuRobo IK failed for range={} seeds={} left_xyz={} left_rpy={}".format(
                    str(spec["range_label"]),
                    tried_seed_labels,
                    [round(v, 6) for v in spec["left_xyz"]],
                    [round(v, 6) for v in quat_wxyz_to_euler_rpy_deg(spec["left_quat"])],
                )
            )
        best_ik_out = best_candidate["ik_out"]
        solved_spec = {
            "range_label": str(spec["range_label"]),
            "range_center": float(spec["range_center"]),
            "q_goal": [float(v) for v in best_ik_out.q_cspace],
            "score": -float(best_candidate["continuity_l2"]),
            "left_force_capacity": 0.0,
            "right_force_capacity": 0.0,
            "seed_label": str(best_candidate["seed_label"]),
            "continuity_target_label": str(continuity_target_label),
            "continuity_target_joint_max_abs": float(best_candidate["continuity_max_abs"]),
            "continuity_target_joint_l2": float(best_candidate["continuity_l2"]),
            "seed_joint_max_abs": float(best_candidate["seed_max_abs"]),
            "seed_joint_l2": float(best_candidate["seed_l2"]),
        }
        solved_specs.append(solved_spec)
        solved_by_label[str(spec["range_label"])] = {
            **solved_spec,
            "left_xyz": [float(v) for v in spec["left_xyz"]],
            "left_quat": [float(v) for v in spec["left_quat"]],
            "right_xyz": [float(v) for v in spec["right_xyz"]],
            "right_quat": [float(v) for v in spec["right_quat"]],
            "target_meta": dict(spec["target_meta"]),
        }

    profiles: List[CartGoalProfile] = []
    for angular_z in angular_bins:
        left_xyz, left_quat, target_meta = build_planar_left_target(
            angular_z=float(angular_z),
            max_abs_angular_z=float(max_abs_angular_z),
            left_target_y_m=float(left_target_y_m),
            left_target_z_m=float(left_target_z_m),
            left_target_roll_deg=float(left_target_roll_deg),
            left_target_pitch_deg=float(left_target_pitch_deg),
        )
        right_xyz, right_quat = build_right_target_from_reference_relation(
            left_target_xyz=left_xyz,
            left_target_quat_wxyz=left_quat,
            p_rel_ref=p_rel_ref,
            q_rel_ref=q_rel_ref,
        )
        range_label = str(target_meta["selected_range_label"])
        solved = solved_by_label[range_label]
        profile = CartGoalProfile(
            angular_z=float(angular_z),
            label="angular_z_{:+.2f}".format(float(angular_z)),
            q_goal=[float(v) for v in solved["q_goal"]],
            left_target_xyz=[float(v) for v in left_xyz],
            left_target_quat_wxyz=[float(v) for v in left_quat],
            right_target_xyz=[float(v) for v in right_xyz],
            right_target_quat_wxyz=[float(v) for v in right_quat],
            score=float(solved["score"]),
            left_force_capacity=float(solved["left_force_capacity"]),
            right_force_capacity=float(solved["right_force_capacity"]),
            metadata={
                **target_meta,
                "shared_q_goal_range_label": str(range_label),
                "ik_seed_source": str(solved["seed_label"]),
                "ik_continuity_target_label": str(solved["continuity_target_label"]),
                "ik_continuity_target_joint_max_abs": float(solved["continuity_target_joint_max_abs"]),
                "ik_continuity_target_joint_l2": float(solved["continuity_target_joint_l2"]),
                "ik_seed_joint_max_abs": float(solved["seed_joint_max_abs"]),
                "ik_seed_joint_l2": float(solved["seed_joint_l2"]),
                "ik_selection_policy": "plain_curobo_min_joint_delta",
            },
        )
        profiles.append(profile)

    return CartGoalLibrary(
        version=1,
        max_abs_angular_z=float(max_abs_angular_z),
        q_reference_cspace=[float(v) for v in q_reference],
        cspace_joint_names=list(CSPACE_JOINT_NAMES_14),
        profiles=profiles,
        metadata={
            "jointstate_topic": str(jointstate_topic),
            "left_ee": str(left_ee),
            "right_ee": str(right_ee),
            "reference_left_xyz": [float(v) for v in reference_left_xyz],
            "reference_left_quat_wxyz": [float(v) for v in reference_left_quat],
            "angular_bins": [float(v) for v in angular_bins],
            "angular_bin_count": int(len(angular_bins)),
            "ik_solver": "plain_curobo_batch",
            "discrete_target_ranges": [
                {
                    "label": str(spec["label"]),
                    "anchor_angular_z": float(spec["anchor_angular_z"]),
                    "range": [
                        float(spec["range_min_angular_z"]),
                        float(spec["range_max_angular_z"]),
                    ],
                    "xyz": [
                        float(spec["target_x_m"]),
                        float(left_target_y_m),
                        float(left_target_z_m),
                    ],
                    "rpy_deg": [
                        float(left_target_roll_deg),
                        float(left_target_pitch_deg),
                        float(spec["target_yaw_deg"]),
                    ],
                }
                for spec in _build_discrete_planar_target_ranges(
                    max_abs_angular_z=float(max_abs_angular_z)
                )
            ],
            "left_target_y_m": float(left_target_y_m),
            "left_target_z_m": float(left_target_z_m),
            "left_target_roll_deg": float(left_target_roll_deg),
            "left_target_pitch_deg": float(left_target_pitch_deg),
        },
    )


def build_cart_profile_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser()
    ap.add_argument("--robot_yml", type=str, default=ROBOT_YAML)
    ap.add_argument("--urdf_path", type=str, default=ROBOT_URDF)
    ap.add_argument("--world_yml", type=str, default=WORLD_YAML)
    ap.add_argument("--joint_limit_yml", type=str, default=JOINT_LIMIT)
    ap.add_argument("--jointstate_topic", type=str, default="/joint_states")
    ap.add_argument("--jointstate_timeout_sec", type=float, default=5.0)
    ap.add_argument("--left_ee", type=str, default=LEFT_EE_FRAME)
    ap.add_argument("--right_ee", type=str, default=RIGHT_EE_FRAME)
    ap.add_argument("--output_json", type=str, required=True)
    ap.add_argument(
        "--angular_bins",
        type=float,
        nargs="+",
        default=None,
        help="explicit angular.z bins to precompute; omit to auto-generate from --angular_step",
    )
    ap.add_argument("--max_abs_angular_z", type=float, default=1.5)
    ap.add_argument("--angular_step", type=float, default=0.1)
    ap.add_argument("--left_target_y_m", type=float, default=0.2)
    ap.add_argument("--left_target_z_m", type=float, default=0.92)
    ap.add_argument("--left_target_roll_deg", type=float, default=90.0)
    ap.add_argument("--left_target_pitch_deg", type=float, default=0.0)
    ap.add_argument("--ik_num_seeds", "--force_ik_num_seeds", dest="ik_num_seeds", type=int, default=20)
    ap.add_argument("--ik_num_trials", "--force_ik_num_trials", dest="ik_num_trials", type=int, default=24)
    ap.add_argument("--ik_seed_noise_std", "--force_ik_seed_noise_std", dest="ik_seed_noise_std", type=float, default=0.25)
    ap.add_argument("--ik_random_seed", "--force_ik_random_seed", dest="ik_random_seed", type=int, default=0)
    ap.add_argument("--forward_direction_base", type=float, nargs=3, default=[1.0, 0.0, 0.0])
    ap.add_argument("--device", type=str, default="cuda", choices=["cuda", "cpu"])
    return ap


def main_cart_profile(argv: Sequence[str] | None = None) -> int:
    args = build_cart_profile_parser().parse_args(list(argv) if argv is not None else None)
    angular_bins = _resolve_angular_bins(
        args.angular_bins,
        max_abs_angular_z=float(args.max_abs_angular_z),
        angular_step=float(args.angular_step),
    )
    print(
        "[cart_profile] angular bins = count:{} first:{:.6f} last:{:.6f}".format(
            len(angular_bins),
            float(angular_bins[0]),
            float(angular_bins[-1]),
        )
    )
    library = build_cart_goal_library(
        robot_yml=str(args.robot_yml),
        urdf_path=str(args.urdf_path),
        world_yml=(None if args.world_yml in (None, "", "none", "None") else str(args.world_yml)),
        joint_limit_yml=str(args.joint_limit_yml),
        jointstate_topic=str(args.jointstate_topic),
        angular_bins=angular_bins,
        max_abs_angular_z=float(args.max_abs_angular_z),
        left_target_y_m=float(args.left_target_y_m),
        left_target_z_m=float(args.left_target_z_m),
        left_target_roll_deg=float(args.left_target_roll_deg),
        left_target_pitch_deg=float(args.left_target_pitch_deg),
        left_ee=str(args.left_ee),
        right_ee=str(args.right_ee),
        device_str=str(args.device),
        ik_num_seeds=int(args.ik_num_seeds),
        ik_num_trials=int(args.ik_num_trials),
        ik_seed_noise_std=float(args.ik_seed_noise_std),
        ik_random_seed=int(args.ik_random_seed),
        forward_direction_base=[float(v) for v in args.forward_direction_base],
        jointstate_timeout_sec=float(args.jointstate_timeout_sec),
    )
    save_cart_goal_library(str(args.output_json), library)
    print(f"[cart_profile] saved: {args.output_json}")
    print(f"[cart_profile] profiles: {len(library.profiles)}")
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    return main_cart_profile(argv)


if __name__ == "__main__":
    raise SystemExit(main())
