#!/usr/bin/env python3

import time
from pathlib import Path

import numpy as np

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState

import PyKDL as kdl
from ros2_impedance_control.urdf import treeFromFile
from ros2_impedance_control.dxl_io import DxlIO
from ros2_impedance_control.kf_currents import CurrentKalmanBank

LEN_TORQUE_ENABLE      = 1
LEN_OPERATING_MODE     = 1
LEN_PRESENT_CURRENT    = 2
LEN_PRESENT_POSITION   = 4
LEN_PRESENT_VELOCITY   = 4
LEN_GOAL_CURRENT       = 2

ADDR_GOAL_CURRENT      = 526
ADDR_PRESENT_CURRENT   = 546
ADDR_PRESENT_VELOCITY  = 548
ADDR_PRESENT_POSITION  = 552

PROJECT_ROOT = Path(__file__).resolve().parents[2]
URDF_PATH = PROJECT_ROOT / "models/urdf/ffw_sg2_rev1_follower/ffw_sg2_follower.urdf"
KDL_ROOT_LINK = "arm_base_link"
KDL_TIP_LINK = "gripper_l_rh_p12_rn_base"
FOLLOWER_JOINT_STATES_TOPIC = "/follower_arm/joint_states"

ARM_LEFT_JOINT_NAMES = [f"arm_l_joint{i}" for i in range(1, 8)]
DXL_IDS = [31, 32, 33, 34, 35, 36, 37]
DEVICENAME = "/dev/ttyAMA2"
BAUDRATE = 6250000
PROTOCOL_VERSION = 2.0

DEFAULT_INIT_Q = np.zeros(len(ARM_LEFT_JOINT_NAMES), dtype=float)

YM080_MODEL = "YM080-230-R099-RH"
YM070_MODEL = "YM070-210-R099-RH"
PH42_MODEL = "PH42-020-S300-R"

JOINT_MODELS = [
    YM080_MODEL, YM080_MODEL, YM080_MODEL,
    YM070_MODEL, YM070_MODEL, YM070_MODEL,
    PH42_MODEL,
]

MODEL_CURRENT_PER_TORQUE = {
    YM080_MODEL: 10.7 / 26.0,
    YM070_MODEL: 11.0 / 14.6,
    PH42_MODEL: 1.5 / 5.1,
}

TORQUE_CONSTANTS = np.array(
    [MODEL_CURRENT_PER_TORQUE[model] for model in JOINT_MODELS],
    dtype=float,
)


class MotorStatePublisher(Node):
    def __init__(self):
        super().__init__("motor_state_publisher")

        self.publisher_ = self.create_publisher(
            JointState,
            FOLLOWER_JOINT_STATES_TOPIC,
            1
        )

        if not URDF_PATH.exists():
            raise FileNotFoundError(f"URDF file not found: {URDF_PATH}")

        suc, self.kdl_tree = treeFromFile(str(URDF_PATH))
        if not suc:
            raise RuntimeError(f"Failed to parse URDF file: {URDF_PATH}")

        self.kdl_chain = self.kdl_tree.getChain(KDL_ROOT_LINK, KDL_TIP_LINK)
        self.num_joints = self.kdl_chain.getNrOfJoints()
        self.gravity = kdl.Vector(0, 0, -9.81)
        self.dynamics = kdl.ChainDynParam(self.kdl_chain, self.gravity)
        self.kdl_joint_array = kdl.JntArray(self.num_joints)
        self.gravity_torque = kdl.JntArray(self.num_joints)
        self.coriolis = kdl.JntArray(self.num_joints)
        self.joint_names = ARM_LEFT_JOINT_NAMES.copy()

        if len(self.joint_names) != self.num_joints:
            raise RuntimeError(
                f"Joint name count ({len(self.joint_names)}) does not match "
                f"KDL chain joints ({self.num_joints})."
            )

        self.get_logger().info(
            f"KDL Chain with {self.num_joints} joints created: "
            f"{KDL_ROOT_LINK} -> {KDL_TIP_LINK}"
        )

        self.dxl_driver = DxlIO(port=DEVICENAME, baudrate=BAUDRATE)
        self.dxl_driver.ids = DXL_IDS.copy()

        if len(self.dxl_driver.ids) != self.num_joints:
            raise RuntimeError(
                f"Motor ID count ({len(self.dxl_driver.ids)}) does not match "
                f"KDL chain joints ({self.num_joints})."
            )

        sleep_time = 0.005

        self.dxl_driver.init_omy_hat(sleep_time)
        time.sleep(sleep_time)

        self.dxl_driver.set_return_delay_time(0)
        time.sleep(sleep_time)

        self.dxl_driver.set_torque(0)
        time.sleep(sleep_time)

        self.dxl_driver.set_drive_mode()
        time.sleep(sleep_time)

        # current control mode
        self.dxl_driver.set_operating_mode(0, debug=True)
        time.sleep(sleep_time)

        self.dxl_driver.set_torque(1)
        time.sleep(sleep_time)

        self.init_q = DEFAULT_INIT_Q.copy()
        self.init_flag = True
        self.q_des = None
        self.dq_des = np.zeros(self.num_joints)

        self.kf_bank = CurrentKalmanBank(
            n_motors=len(self.dxl_driver.ids), q=5.0, r=25.0
        )

        timer_period = 0.0025  # 400Hz
        self.timer = self.create_timer(timer_period, self.timer_callback)

        self.get_logger().info("Standalone follower arm controller ready.")

    def timer_callback(self):
        positions, velocities, currents = self.dxl_driver.sync_read_pos_vel_cur()

        q = np.array(positions, dtype=float) * 2.0 * np.pi / 524288.0
        dq = np.array(velocities, dtype=float) * 2.0 * np.pi / 60.0 * 0.01

        if q.size != self.num_joints or dq.size != self.num_joints:
            self.get_logger().error(
                f"Read {q.size} positions / {dq.size} velocities, "
                f"but KDL chain expects {self.num_joints} joints."
            )
            return

        # 초기 자세에 도달하면 그 자세를 유지
        if self.init_flag:
            if np.linalg.norm(q - self.init_q) < 0.2:
                self.get_logger().info("Init position reached. Holding current pose.")
                self.init_flag = False
                self.q_des = q.copy()
                self.dq_des = np.zeros(self.num_joints)

        if self.init_flag:
            q_des = self.init_q
            dq_des = np.zeros(self.num_joints)
        else:
            if self.q_des is None:
                self.q_des = q.copy()
            q_des = self.q_des
            dq_des = self.dq_des

        for i in range(self.num_joints):
            self.kdl_joint_array[i] = q[i]

        self.dynamics.JntToGravity(self.kdl_joint_array, self.gravity_torque)
        g = np.array([self.gravity_torque[i] for i in range(self.num_joints)])

        torque_constants = TORQUE_CONSTANTS.copy()
        if torque_constants.size != self.num_joints:
            self.get_logger().error(
                f"Torque constant count ({torque_constants.size}) does not match "
                f"KDL chain joints ({self.num_joints})."
            )
            return

        q_error = q_des - q
        dq_error = dq_des - dq

        kp = np.eye(self.num_joints) * 150.0
        kd = np.eye(self.num_joints) * 6.0

        ddq_ref = kp @ q_error + kd @ dq_error

        self.dynamics.JntToCoriolis(
            self.joint_list_to_kdl(q),
            self.joint_list_to_kdl(dq),
            self.coriolis
        )
        coriolis = np.array([self.coriolis[i] for i in range(self.num_joints)])

        err_direction = np.sign(q_error)
        if np.all(np.abs(q_error) < 0.01):
            err_direction = np.zeros(self.num_joints)

        coulomb_friction = err_direction * 3.0
        if self.num_joints > 1:
            coulomb_friction[1] *= 2.0

        tau_desired = ddq_ref + coriolis + coulomb_friction + g

        currents_kf = self.kf_bank.step(currents, return_dtype="float")

        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.name = self.joint_names
        msg.position = q.tolist()
        msg.velocity = dq.tolist()
        msg.effort = currents_kf.tolist()
        self.publisher_.publish(msg)

        if np.isnan(tau_desired).any():
            self.get_logger().error("NaN in tau_desired, skipping this control step.")
            return

        goal_currents = tau_desired * torque_constants
        self.dxl_driver.sync_write_goal_currents(goal_currents)

    def torque_off(self):
        self.get_logger().info("Turning off torque...")
        self.dxl_driver.set_torque(0)
        time.sleep(0.5)

    def joint_list_to_kdl(self, q):
        if q is None:
            return None
        if isinstance(q, np.matrix) and q.shape[1] == 0:
            q = q.T.tolist()[0]
        q_kdl = kdl.JntArray(len(q))
        for i, q_i in enumerate(q):
            q_kdl[i] = q_i
        return q_kdl

    def jntarray_to_np(self, jnt_array):
        return np.array([jnt_array[i] for i in range(jnt_array.rows())])

    def inertia_to_np(self, H):
        n = H.rows()
        H_np = np.zeros((n, n))
        for i in range(n):
            for j in range(n):
                H_np[i, j] = H[i, j]
        return H_np

    def __del__(self):
        pass


def main(args=None):
    rclpy.init(args=args)

    np.set_printoptions(precision=3, suppress=True, linewidth=120)
    np.random.seed(11)

    motor_state_node = MotorStatePublisher()
    try:
        rclpy.spin(motor_state_node)
    except KeyboardInterrupt:
        print("KeyboardInterrupt received.")
    finally:
        motor_state_node.dxl_driver.set_torque(0)
        motor_state_node.dxl_driver.close()
        motor_state_node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()