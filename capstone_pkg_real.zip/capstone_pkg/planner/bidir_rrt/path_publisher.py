from __future__ import annotations

import time
from typing import Sequence

import rclpy
from builtin_interfaces.msg import Duration
from rclpy.node import Node
from sensor_msgs.msg import JointState
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint


def _duration_from_seconds(seconds: float) -> Duration:
    sec = int(seconds)
    nanosec = int(round((seconds - sec) * 1e9))
    if nanosec >= 1_000_000_000:
        sec += 1
        nanosec -= 1_000_000_000
    return Duration(sec=sec, nanosec=nanosec)


def publish_joint_path(
    path: Sequence[Sequence[float]],
    joint_names: Sequence[str],
    *,
    topic: str = "/joint_states_cmd",
    dt: float = 0.1,
    wait_subscriber_s: float = 1.0,
) -> None:
    """Publish a joint-space path as JointState sequence to a ROS2 topic."""
    if not path:
        raise ValueError("path is empty")
    if not joint_names:
        raise ValueError("joint_names is empty")
    if dt <= 0.0:
        raise ValueError("dt must be > 0")

    n = len(joint_names)
    for i, q in enumerate(path):
        if len(q) != n:
            raise ValueError(f"path[{i}] length {len(q)} != len(joint_names) {n}")

    owns_rclpy = False
    if not rclpy.ok():
        rclpy.init()
        owns_rclpy = True

    node = Node("bidir_rrt_path_publisher")
    pub = node.create_publisher(JointState, topic, 10)

    # Give DDS graph discovery time so first samples are less likely to be dropped.
    t_end = time.monotonic() + max(0.0, float(wait_subscriber_s))
    while rclpy.ok() and time.monotonic() < t_end and pub.get_subscription_count() == 0:
        rclpy.spin_once(node, timeout_sec=0.05)

    for idx, q in enumerate(path):
        msg = JointState()
        msg.header.stamp = node.get_clock().now().to_msg()
        msg.name = list(joint_names)
        msg.position = [float(v) for v in q]
        pub.publish(msg)
        rclpy.spin_once(node, timeout_sec=0.0)
        if idx + 1 < len(path):
            time.sleep(dt)

    # Publish goal once more to help the last command stick at receiver side.
    last = path[-1]
    msg = JointState()
    msg.header.stamp = node.get_clock().now().to_msg()
    msg.name = list(joint_names)
    msg.position = [float(v) for v in last]
    pub.publish(msg)
    rclpy.spin_once(node, timeout_sec=0.05)

    node.destroy_node()
    if owns_rclpy:
        rclpy.shutdown()


def publish_joint_trajectory(
    path: Sequence[Sequence[float]],
    joint_names: Sequence[str],
    *,
    topic: str,
    dt: float = 0.1,
    wait_subscriber_s: float = 1.0,
    publish_repeat: int = 2,
    publish_period_s: float = 0.05,
) -> None:
    """Publish joint-space waypoints as a JointTrajectory command."""
    if not path:
        raise ValueError("path is empty")
    if not joint_names:
        raise ValueError("joint_names is empty")
    if dt <= 0.0:
        raise ValueError("dt must be > 0")

    n = len(joint_names)
    for i, q in enumerate(path):
        if len(q) != n:
            raise ValueError(f"path[{i}] length {len(q)} != len(joint_names) {n}")

    owns_rclpy = False
    if not rclpy.ok():
        rclpy.init()
        owns_rclpy = True

    node = Node("bidir_rrt_traj_publisher")
    pub = node.create_publisher(JointTrajectory, topic, 10)

    # Give DDS graph discovery time so first samples are less likely to be dropped.
    t_end = time.monotonic() + max(0.0, float(wait_subscriber_s))
    while rclpy.ok() and time.monotonic() < t_end and pub.get_subscription_count() == 0:
        rclpy.spin_once(node, timeout_sec=0.05)

    msg = JointTrajectory()
    msg.joint_names = list(joint_names)

    for idx, q in enumerate(path):
        p = JointTrajectoryPoint()
        p.positions = [float(v) for v in q]
        p.time_from_start = _duration_from_seconds(float(idx) * float(dt))
        msg.points.append(p)

    repeats = max(1, int(publish_repeat))
    for i in range(repeats):
        msg.header.stamp = node.get_clock().now().to_msg()
        pub.publish(msg)
        rclpy.spin_once(node, timeout_sec=0.0)
        if i + 1 < repeats:
            time.sleep(max(0.0, float(publish_period_s)))

    node.destroy_node()
    if owns_rclpy:
        rclpy.shutdown()
